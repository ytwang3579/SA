#!/bin/sh

ls -ARl | awk '/^d|^-/' | sort -nrk 5 | awk 'BEGIN{size=0; dir=0; file=0; cnt=0;} {cnt++; if(cnt<=5) print $5 " " $9; if($1~/^d/) dir++; if($1~/^-/) file++; size+=$5;} END{print "Dir num: "dir; print "File num: "file; print "Total: "size}'
